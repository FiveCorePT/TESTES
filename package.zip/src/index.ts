import {
  Client,
  Events,
  GatewayIntentBits,
  MessageFlags,
  REST,
  Routes,
  SlashCommandBuilder,
} from "discord.js";
import { env } from "./config/env.js";
import { prisma } from "./database/client.js";
import { registarAuditoria } from "./core/auditoria.js";
import { registarServidor } from "./core/servidores.js";

const comandos = [
  new SlashCommandBuilder()
    .setName("ping")
    .setDescription("Verifica se o bot está online"),
];

const client = new Client({ intents: [GatewayIntentBits.Guilds] });

client.once(Events.ClientReady, async (c) => {
  console.log(`✅ Online como ${c.user.tag}`);

  // Regista os servidores na base de dados
  for (const guild of c.guilds.cache.values()) {
    try {
      await registarServidor(guild);
      console.log(`🗄️ Servidor guardado: ${guild.name}`);
    } catch (erro) {
      console.error(`❌ Falhou ao guardar ${guild.name}:`, erro);
    }
  }

  // Regista os comandos nos dois servidores de teste
  const rest = new REST().setToken(env.token);
  for (const guildId of [env.mainGuildId, env.devGuildId]) {
    try {
      await rest.put(Routes.applicationGuildCommands(env.clientId, guildId), {
        body: comandos.map((cmd) => cmd.toJSON()),
      });
      console.log(`📌 Comandos registados no servidor ${guildId}`);
    } catch (erro) {
      console.error(`❌ Falhou o registo no servidor ${guildId}:`, erro);
    }
  }
});

// Quando o bot entra num servidor novo
client.on(Events.GuildCreate, async (guild) => {
  await registarServidor(guild);
  console.log(`➕ Novo servidor: ${guild.name}`);
});

client.on(Events.InteractionCreate, async (interaction) => {
  if (!interaction.isChatInputCommand() || !interaction.guildId) return;

  if (interaction.commandName === "ping") {
    await registarAuditoria({
      servidorId: interaction.guildId,
      autorId: interaction.user.id,
      modulo: "teste",
      acao: "ping.usado",
    });

    const total = await prisma.auditoria.count({
      where: { servidorId: interaction.guildId },
    });

    await interaction.reply({
      content: `🏓 Pong! Latência: ${client.ws.ping}ms\n🗄️ Registos de auditoria neste servidor: ${total}`,
      flags: MessageFlags.Ephemeral,
    });
  }
});

client.login(env.token);