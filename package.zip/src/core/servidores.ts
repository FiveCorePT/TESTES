import type { Guild } from "discord.js";
import { env } from "../config/env.js";
import { prisma } from "../database/client.js";

export async function registarServidor(guild: Guild) {
  const tipo = guild.id === env.mainGuildId ? "PRINCIPAL" : "DEPARTAMENTO";

  await prisma.servidor.upsert({
    where: { id: guild.id },
    update: { nome: guild.name },
    create: {
      id: guild.id,
      nome: guild.name,
      tipo,
      config: { create: {} }, // cria já a configuração vazia
    },
  });
}