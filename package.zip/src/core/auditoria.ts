import type { Prisma } from "../generated/prisma/client.js";
import { prisma } from "../database/client.js";

interface DadosAuditoria {
  servidorId: string;
  autorId: string;
  modulo: string;
  acao: string;
  alvoId?: string;
  antes?: Prisma.InputJsonValue;
  depois?: Prisma.InputJsonValue;
  reversivel?: boolean;
}

export async function registarAuditoria(dados: DadosAuditoria) {
  return prisma.auditoria.create({
    data: {
      servidorId: dados.servidorId,
      autorId: dados.autorId,
      modulo: dados.modulo,
      acao: dados.acao,
      alvoId: dados.alvoId,
      antes: dados.antes,
      depois: dados.depois,
      reversivel: dados.reversivel ?? false,
    },
  });
}